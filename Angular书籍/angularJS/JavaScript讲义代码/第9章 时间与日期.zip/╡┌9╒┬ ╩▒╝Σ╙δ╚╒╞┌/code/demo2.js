

/*

var box = new Date(2007, 10, 15, 17, 22, 45, 15);
alert(box);																	//Thu Nov 15 2007 17:22:45 GMT+0800
alert('toString:' + box.toString());									//Thu Nov 15 2007 17:22:45 GMT+0800 
alert('toLocaleString:' + box.toLocaleString());				//2007-11-15 17:22:45 PS�ȸ践�ص�Thu Nov 15 2007 17:22:45 GMT+0800 
alert('valueOf:' + box.valueOf());									//1195118565015


var box = new Date(2007, 10, 15, 17, 22, 45, 15);
alert(box.toDateString());
alert(box.toTimeString());
alert(box.toLocaleDateString());
alert(box.toLocaleTimeString());
alert(box.toUTCString());

box.setTime(100);
alert(box.getTime());
alert(box.getYear());//����
box.setFullYear(2009);
alert(box.getFullYear());
box.setMonth(5);
alert(box.getMonth());

var box = new Date();
alert(box.getMonth() + 1);

alert(box.getMonth() + 1); //�·�Ҫ��1�������յ��·�

box.setUTCFullYear(2008);
alert(box.getUTCFullYear());

alert(box.getUTCHours()); //��������8��Сʱ�Ĳ��
����getUTCHous��getHous���8��Сʱ

var box = new Date(2007, 10, 15, 10, 22, 45, 15);
alert(box.getTimezoneOffset());
*/




var box = new Date();
alert(box.getFullYear() + '-' + box.getMonth() + '-' + box.getDate() + ' ' + box.getHours() + ':' + box.getMinutes() + ':' + box.getSeconds());















